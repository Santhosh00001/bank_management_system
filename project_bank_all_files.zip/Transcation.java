
package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Transcation extends JFrame implements ActionListener {
    JButton deposit,withdrawl,fastcash,ministate,pinchange,balanceenq,exit;
    String pinnumber;
        Transcation(String pinnumber){
            this.pinnumber=pinnumber;
            setLayout(null);
            
            ImageIcon l1 = new ImageIcon("C:\\Users\\Nani\\Downloads\\atm.jpg");
            Image l2 = l1.getImage().getScaledInstance(900,900,Image.SCALE_DEFAULT);
            ImageIcon l3 = new ImageIcon(l2);
            JLabel image = new JLabel(l3);
            image.setBounds(0,0,900,900);
            add(image);
            
            JLabel text =  new JLabel("Please Select your Transcation");
            text.setBounds(210,300,700,35);
            text.setForeground(Color.white);
            text.setFont(new Font("System",Font.BOLD,16));
            image.add(text);
            
            deposit = new JButton("Deposit");
            deposit.setBounds(170,390,150,25);
            deposit.addActionListener(this);
            image.add(deposit);
            
            withdrawl = new JButton("Cash WithDrawl");
            withdrawl.setBounds(355,390,150,25);
            withdrawl.addActionListener(this);
            image.add(withdrawl);
            
            
            fastcash = new JButton("Fast Cash");
            fastcash.setBounds(170,425,150,25);
            fastcash.addActionListener(this);
            image.add(fastcash);
            
            ministate = new JButton("Mini Statement");
            ministate.setBounds(355,425,150,25);
            ministate.addActionListener(this);
            image.add(ministate);
            
            pinchange = new JButton("Pin Change");
            pinchange.setBounds(170,460,150,25);
            pinchange.addActionListener(this);
            image.add(pinchange);
            
            balanceenq = new JButton("Balance Enquiry");
            balanceenq.setBounds(355,460,150,25);
            balanceenq.addActionListener(this);
            image.add(balanceenq);
            
            exit = new JButton("Exit");
            exit.setBounds(355,490,150,25);
            exit.addActionListener(this);
            image.add(exit);
            
            
            setSize(900,900);
            setLocation(300,0);
           setUndecorated(true);
            setVisible(true);
        }
        public void actionPerformed(ActionEvent ae){
            if(ae.getSource()==exit){
                System.exit(0);
            }
            else if(ae.getSource()==deposit){
                setVisible(false);
                new Deposit(pinnumber).setVisible(true);
            }else if(ae.getSource()==withdrawl){
                setVisible(false);
                new WithDrawl(pinnumber).setVisible(true);
            }else if(ae.getSource()==fastcash){
                setVisible(false);
                new Fastcash(pinnumber).setVisible(true);
            }else if(ae.getSource()==pinchange){
                setVisible(false);
                new Pinchange(pinnumber).setVisible(true);
            }else if(ae.getSource()==balanceenq){
                setVisible(false);
                new Balanceenquiry(pinnumber).setVisible(true);
            }else if(ae.getSource()==ministate){
                //setVisible(true);
                new Ministate(pinnumber).setVisible(true);
            }
        }
    
    public static void main(String args[]) {
        new Transcation("");
    }
}
