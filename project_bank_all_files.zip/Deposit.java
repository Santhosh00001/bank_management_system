package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Deposit extends JFrame implements ActionListener{
    
    JTextField amount;
    JButton deposit,back; 
    String pinnumber;
    
    Deposit(String pinnumber){
        this.pinnumber=pinnumber;
        
        setLayout(null);
        ImageIcon l1 = new ImageIcon(ClassLoader.getSystemResource("icon/atm.jpg"));
        Image l2 = l1.getImage().getScaledInstance(900,900,Image.SCALE_DEFAULT);
        ImageIcon l3 = new ImageIcon(l2);
        JLabel image = new JLabel(l3);
        image.setBounds(0,0,900,900);
        add(image);
            
        JLabel text = new JLabel("Enter the amount you want to Deposit");
        text.setForeground(Color.white);
        //text.setBackground(Color.);
        text.setFont(new Font("System",Font.BOLD,14));
        text.setBounds(170,300,400,20);
        image.add(text);
        
        amount = new JTextField();
        amount.setFont(new Font("Raleway",Font.BOLD,22));
        amount.setBounds(170,350,320,25);
        image.add(amount);
        
        deposit = new JButton("Deposit");
        deposit.setBounds(355,485,150,30);
        deposit.addActionListener(this);
        image.add(deposit);
        
        back = new JButton("Back");
        back.setBounds(355,520,150,30);
        back.addActionListener(this);
        image.add(back);
        
        setSize(900,900);
        setLocation(300,0);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==deposit){
            String number = amount.getText();
            Date date = new Date();
            if(number.equals("")){
                JOptionPane.showMessageDialog(null,"please enter the amount you want to deposit");
                
            }else{
                try{
                    double depositAmount = Double.parseDouble(number);
                    if(depositAmount<=0){
                        JOptionPane.showMessageDialog(null,"Deposit amount must be positive");
                        return;
                    }
                Conn conn = new Conn();
                
                String query = "insert into bank values('"+pinnumber+"','"+date+"','Deposit','"+number+"')";
                conn.s.execute(query);
                JOptionPane.showMessageDialog(null,"Rs "+number+" Deposited Successfully");
                setVisible(false);
                new Transcation(pinnumber).setVisible(true);
                }catch(NumberFormatException e){
                    JOptionPane.showMessageDialog(null,"Please enter a vaild number");
                }catch(Exception e){
                    System.out.println(e);
                }
            }
        }
        else if(ae.getSource()==back){
            setVisible(false);
            new Transcation(pinnumber).setVisible(true);
        }
    }

    
    public static void main(String args[]) {
        new Deposit("");
    }
}
