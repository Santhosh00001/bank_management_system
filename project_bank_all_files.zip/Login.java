package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Login extends JFrame implements ActionListener{
    JButton login,clear,signup;
    JTextField cardtxtfield; 
    JPasswordField pintxtfield;
    Login(){
        setTitle("AUTOMATED TELLER MACHINE");
        setLayout(null);
       // ImageIcon im = new ImageIcon("C:\\Users\\Nani\\Downloads\\logo.jpg");
        ImageIcon im = new ImageIcon(ClassLoader.getSystemResource("icon/logo.jpg"));
        Image im2 = im.getImage().getScaledInstance(100,100,Image.SCALE_DEFAULT);
        ImageIcon im3 = new ImageIcon(im2);
        JLabel label = new JLabel(im3);
        label.setBounds(70,10,100,100);
        add(label);
        
        JLabel text = new JLabel("Welcome to ATM");
        text.setFont(new Font("Osward",Font.BOLD,38));
        text.setBounds(200,40,400,40);
        add(text);
        
        
        //this code is create cardno text in that box
        JLabel cardno = new JLabel("Card No:");
        cardno.setFont(new Font("Raleway",Font.BOLD,28));
        cardno.setBounds(120,150,400,40);
        add(cardno);
        
        //this text field to take the card input
        cardtxtfield = new JTextField();
        cardtxtfield.setBounds(300,160,250,30);
        cardtxtfield.setFont(new Font("Arial",Font.BOLD,14));
        add(cardtxtfield);
        
        //this is used to create name pin
        JLabel pin = new JLabel("PIN:");
        pin.setFont(new Font("Raleway",Font.BOLD,28));
        pin.setBounds(120,220,400,40);
        add(pin);
        
        //this is to declare textfield to take input
        pintxtfield = new JPasswordField();
        pintxtfield.setBounds(300,230,250,30);
        pintxtfield.setFont(new Font("Arial",Font.BOLD,14));
        add(pintxtfield);
        
        //Button of signin
        login = new JButton("SignIn");
        login.setBounds(300,300,100,30);
        login.addActionListener(this);
        add(login);
        
        //button of clear
        clear = new JButton("Clear");
        clear.setBounds(450,300,100,30);
        clear.addActionListener(this);
        add(clear);
        
        //button ofsignup
         signup = new JButton("SignUp");
        signup.setBounds(300,350,250,30);
        signup.addActionListener(this);
        add(signup);
        
        //setting backgroundcolor of panel and panel size
        //and setting visible to true to show the panel/window
        //location is used to pop the window in which place of the 
        //screen
        getContentPane().setBackground(Color.WHITE);
        setSize(800,480);
        setVisible(true);
        setLocation(350,200);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()== clear){
                cardtxtfield.setText("");
                pintxtfield.setText("");
        }
        else if(ae.getSource() == signup){
            setVisible(false);
            new SignUpone().setVisible(true);
        }
        else if(ae.getSource() == login){
           Conn conn = null;
            try {
                conn = new Conn();
            } catch (SQLException ex) {
                Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
            }
           String cardnumber = cardtxtfield.getText();
           String pinnumber = pintxtfield.getText();
           String query = "select * from login where cardnumber='"+cardnumber+"'and pin = '"+pinnumber+"'";
           try{
               ResultSet rs = conn.s.executeQuery(query);
               if(rs.next()){
                   setVisible(false);
                   new Transcation(pinnumber).setVisible(true);
               }
               else{
                   JOptionPane.showMessageDialog(null,"Incorrect Card Number or Pin");
               }
           }catch(Exception e){
               System.out.println(e);
           }
        }
            
    }

    public static void main(String args[]) {
        new Login();
    }
}
