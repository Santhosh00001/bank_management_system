package bank.management.system;
import java.sql.*;

public class Conn implements AutoCloseable {
    Connection c;
    Statement s;
    
    public Conn() throws SQLException{    
        try{
           // Class.forName(com.mysql.cj.jdbc.Driver);
            c = DriverManager.getConnection("jdbc:mysql:///bankmanagementsystem","root","santhosh@112");
            s = c.createStatement();
            
        }catch(SQLException e){
            throw e;
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void close() {
        try { if (s != null) s.close(); } catch (SQLException e) { e.printStackTrace(); }
        try { if (c != null) c.close(); } catch (SQLException e) { e.printStackTrace(); }
    }

}
