
package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Fastcash extends JFrame implements ActionListener {
    JButton deposit,withdrawl,fastcash,ministate,pinchange,balanceenq,back;
    String pinnumber;
        Fastcash(String pinnumber){
            this.pinnumber=pinnumber;
            setLayout(null);
            
            ImageIcon l1 = new ImageIcon("C:\\Users\\Nani\\Downloads\\atm.jpg");
            Image l2 = l1.getImage().getScaledInstance(900,900,Image.SCALE_DEFAULT);
            ImageIcon l3 = new ImageIcon(l2);
            JLabel image = new JLabel(l3);
            image.setBounds(0,0,900,900);
            add(image);
            
            JLabel text =  new JLabel("Select withdrawl amount");
            text.setBounds(210,300,700,35);
            text.setForeground(Color.white);
            text.setFont(new Font("System",Font.BOLD,16));
            image.add(text);
            
            deposit = new JButton("Rs 100");
            deposit.setBounds(170,390,150,25);
            deposit.addActionListener(this);
            image.add(deposit);
            
            withdrawl = new JButton("Rs 500");
            withdrawl.setBounds(355,390,150,25);
            withdrawl.addActionListener(this);
            image.add(withdrawl);
            
            
            fastcash = new JButton("Rs 1000");
            fastcash.setBounds(170,425,150,25);
            fastcash.addActionListener(this);
            image.add(fastcash);
            
            ministate = new JButton("Rs 2000");
            ministate.setBounds(355,425,150,25);
            ministate.addActionListener(this);
            image.add(ministate);
            
            pinchange = new JButton("Rs 5000");
            pinchange.setBounds(170,460,150,25);
            pinchange.addActionListener(this);
            image.add(pinchange);
            
            balanceenq = new JButton("Rs 10000");
            balanceenq.setBounds(355,460,150,25);
            balanceenq.addActionListener(this);
            image.add(balanceenq);
            
            back = new JButton("Back");
            back.setBounds(355,490,150,25);
            back.addActionListener(this);
            image.add(back);
            
            
            setSize(900,900);
            setLocation(300,0);
           setUndecorated(true);
            setVisible(true);
        }
        public void actionPerformed(ActionEvent ae){
            if(ae.getSource()==back){
                setVisible(false);
                new Transcation(pinnumber).setVisible(true);
            }
            else{
                String amount = ((JButton)ae.getSource()).getText().substring(3);
                Conn c = null;
                try {
                    c = new Conn();
                } catch (SQLException ex) {
                    Logger.getLogger(Fastcash.class.getName()).log(Level.SEVERE, null, ex);
                }
                try{
                    ResultSet rs = c.s.executeQuery("Select * from bank where pin = '"+pinnumber+"'");
                    int balance  =0;
                    while(rs.next()){
                        if(rs.getString("type").equals("Deposit")){
                            balance +=Integer.parseInt(rs.getString("amount"));
                        } else{
                            balance -=Integer.parseInt(rs.getString("amount"));
                        }
                    }
                    if(ae.getSource()!=back && balance < Integer.parseInt(amount)){
                        JOptionPane.showMessageDialog(null,"Insufficient Balance");
                        return;
                    }
                    Date date = new Date();
                    //SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    //String formatedDate= formatter.format(date);
                    String query = "insert into bank values('"+pinnumber+"','"+date+"','Withdrawl','"+amount+"')";
                    c.s.executeUpdate(query);
                    JOptionPane.showMessageDialog(null,"Rs "+amount+" Debited Successfully");
                    setVisible(false);
                    new Transcation(pinnumber).setVisible(true);
                }catch(Exception e){
                    System.out.println(e);
                }
            }
        }
    
    public static void main(String args[]) {
        new Fastcash("");
    }
}
