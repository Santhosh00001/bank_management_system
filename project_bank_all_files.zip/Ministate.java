package bank.management.system;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.text.NumberFormat;
import java.util.Locale;

public class Ministate extends JFrame{
        Ministate(String pinnumber){
             setTitle("Mini Statement");
        setLayout(new BorderLayout());
        getContentPane().setBackground(Color.WHITE);

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setBackground(Color.WHITE);
        
        JLabel bank = new JLabel("People's Bank", SwingConstants.CENTER);
        bank.setFont(new Font("Arial", Font.BOLD, 18));
        headerPanel.add(bank);
        
        JLabel card = new JLabel("", SwingConstants.CENTER);
        card.setFont(new Font("Arial", Font.PLAIN, 14));
        headerPanel.add(card);
        
        add(headerPanel, BorderLayout.NORTH);

        // Transaction Panel
        JTextArea miniTextArea = new JTextArea();
        miniTextArea.setEditable(false);
        miniTextArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(miniTextArea);
        add(scrollPane, BorderLayout.CENTER);

        // Balance Panel
        JLabel balanceLabel = new JLabel("", SwingConstants.CENTER);
        balanceLabel.setFont(new Font("Arial", Font.BOLD, 14));
        add(balanceLabel, BorderLayout.SOUTH);
            
            
            try {
            Conn conn = new Conn();
            
            // Get card number
            String cardQuery = "SELECT cardnumber FROM login WHERE pin = ?";
            try (PreparedStatement cardStmt = conn.c.prepareStatement(cardQuery)) {
                cardStmt.setString(1, pinnumber);
                ResultSet rs = cardStmt.executeQuery();
                if (rs.next()) {
                    String cardNumber = rs.getString("cardnumber");
                    card.setText("Card Number: " + cardNumber.substring(0,4) + "XXXXXXX");
                }
            }

            // Get transactions
            String transQuery = "SELECT date, type, amount FROM bank WHERE pin = ? " +
                              "ORDER BY STR_TO_DATE(date, '%a %b %d %H:%i:%s IST %Y') DESC LIMIT 10";
            try (PreparedStatement transStmt = conn.c.prepareStatement(transQuery)) {
                transStmt.setString(1, pinnumber);
                ResultSet rs = transStmt.executeQuery();

                StringBuilder transactions = new StringBuilder();
                NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
                int balance = 0;

                transactions.append(String.format("%-20s %-10s %10s\n", "Date", "Type", "Amount"));
                transactions.append("------------------------------------------\n");

                while (rs.next()) {
                    String date = rs.getString("date");
                    String type = rs.getString("type");
                    String amountStr = rs.getString("amount");

                    try {
                        int amount = Integer.parseInt(amountStr);
                        if ("Deposit".equalsIgnoreCase(type)) {
                            balance += amount;
                        } else {
                            balance -= amount;
                        }

                        transactions.append(String.format("%-20s %-10s %10s\n", 
                            date, 
                            type, 
                            currencyFormat.format(amount)));
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid amount format: " + amountStr);
                    }
                }

                miniTextArea.setText(transactions.toString());
                balanceLabel.setText("Current Balance: " + currencyFormat.format(balance));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading transactions: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    
    public static void main(String args[]) {
        new Ministate("");
    }
}
