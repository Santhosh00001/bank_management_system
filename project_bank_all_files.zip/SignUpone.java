package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.util.*;

import java.awt.event.*;
//to use calendar field for dob u have to import
//this jar folder
import com.toedter.calendar.JDateChooser;


public class SignUpone extends JFrame implements ActionListener{
    long random;
    JTextField nametxt,fnametxt,
            emailnametxt,addtxt,citytxt,statetxt,pintxt;
    JRadioButton male,female,married,unmarried,Other;
    JButton next;
    JDateChooser dateChooser;
    
    SignUpone(){
        //layout should be kept null to use
        //apply setBounds
        setLayout(null);
        Random num = new Random();
        random = Math.abs((num.nextLong()%9000L)+1000L);
        
        JLabel formno = new JLabel("Application Form no."+ random);
        formno.setFont(new Font("Raleway",Font.BOLD,38));
        //setBOunds works when setLayout is null
        formno.setBounds(180,20,600,40);
        add(formno);
        
        JLabel personalDetails = new JLabel("Page 1 : Personal Deatails");
        personalDetails.setFont(new Font("Raleway",Font.BOLD,28));
        personalDetails.setBounds(250,100,600,40);
        add(personalDetails);
        
        JLabel name = new JLabel("Name:");
        name.setFont(new Font("Raleway",Font.BOLD,20));
        name.setBounds(100,180,600,40);
        add(name);
        
        nametxt = new JTextField();
        nametxt.setBounds(300,190,400,30);
        nametxt.setFont(new Font("Arial",Font.BOLD,14));
        add(nametxt);
        
        JLabel fname = new JLabel("Father_name:");
        fname.setFont(new Font("Raleway",Font.BOLD,20));
        fname.setBounds(100,230,600,40);
        add(fname);
        
        fnametxt = new JTextField();
        fnametxt.setBounds(300,240,400,30);
        fnametxt.setFont(new Font("Arial",Font.BOLD,14));
        add(fnametxt);
        
        
        JLabel dob = new JLabel("DOB:");
        dob.setFont(new Font("Raleway",Font.BOLD,20));
        dob.setBounds(100,280,600,40);
        add(dob);
        
        dateChooser = new JDateChooser();
        dateChooser.setBounds(300,290,400,30);
        add(dateChooser);
        
        JLabel gender = new JLabel("Gender:");
        gender.setFont(new Font("Raleway",Font.BOLD,20));
        gender.setBounds(100,330,600,40);
        add(gender);
        
        JLabel email = new JLabel("Email:");
        email.setFont(new Font("Raleway",Font.BOLD,20));
        email.setBounds(100,380,600,40);
        add(email);
        
        male = new JRadioButton("Male");
        male.setBackground(Color.white);
        male.setBounds(300,340,60,30);
        add(male);
        
        female = new JRadioButton("Female");
        female.setBackground(Color.white);
        female.setBounds(450,340,80,30);
        add(female);
        
        ButtonGroup gendergroup = new ButtonGroup();
        gendergroup.add(male);
        gendergroup.add(female);
        
        emailnametxt = new JTextField();
        emailnametxt.setBounds(300,390,400,30);
        emailnametxt.setFont(new Font("Arial",Font.BOLD,14));
        add(emailnametxt);
        
        
        JLabel maritalsts= new JLabel("Marital Status:");
        maritalsts.setFont(new Font("Raleway",Font.BOLD,20));
        maritalsts.setBounds(100,430,600,40);
        add(maritalsts);
        
        married = new JRadioButton("Married");
        married.setBackground(Color.white);
        married.setBounds(300,440,100,30);
        add(married);
        
        unmarried = new JRadioButton("UnMarried");
        unmarried.setBackground(Color.white);
        unmarried.setBounds(450,440,100,30);
        add(unmarried);
        
        Other = new JRadioButton("Other");
        Other.setBackground(Color.white);
        Other.setBounds(600,440,100,30);
        add(Other);
        
        
        ButtonGroup maritalgroup = new ButtonGroup();
        maritalgroup.add(married);
        maritalgroup.add(Other);
        maritalgroup.add(unmarried);
        
        
        
        JLabel Address= new JLabel("Address:");
        Address.setFont(new Font("Raleway",Font.BOLD,20));
        Address.setBounds(100,480,600,40);
        add(Address);
        
        addtxt = new JTextField();
        addtxt.setBounds(300,490,400,30);
        addtxt.setFont(new Font("Arial",Font.BOLD,14));
        add(addtxt);
        
        
        JLabel city= new JLabel("City:");
        city.setFont(new Font("Raleway",Font.BOLD,20));
        city.setBounds(100,530,600,40);
        add(city);
        
        citytxt = new JTextField();
        citytxt.setBounds(300,540,400,30);
        citytxt.setFont(new Font("Arial",Font.BOLD,14));
        add(citytxt);
                
        
        JLabel State= new JLabel("State:");
        State.setFont(new Font("Raleway",Font.BOLD,20));
        State.setBounds(100,580,600,40);
        add(State);
        
        statetxt = new JTextField();
        statetxt.setBounds(300,590,400,30);
        statetxt.setFont(new Font("Arial",Font.BOLD,14));
        add(statetxt);
        
        JLabel pincode = new JLabel("PinCode:");
        pincode.setFont(new Font("Raleway",Font.BOLD,20));
        pincode.setBounds(100,630,600,40);
        add(pincode);
        
        pintxt = new JTextField();
        pintxt.setBounds(300,640,400,30);
        pintxt.setFont(new Font("Arial",Font.BOLD,14));
        add(pintxt);
        
        next = new JButton("Next");
       // next.setBackground(Color.black);
        next.setFont(new Font("Raleway",Font.BOLD,14));
        next.setBounds(620,700,80,30);
        next.addActionListener(this);
        add(next);
        
        
        getContentPane().setBackground(Color.white);
        setSize(850,800);
        setLocation(350,10);
        setVisible(true);
    }
    private boolean isValidEmail(String email){
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return email.matches(emailRegex);
    }
    public void actionPerformed(ActionEvent ae){
        String formno = " " + random;
        String name = nametxt.getText();
        String fname = fnametxt.getText();
        String dob = ((JTextField)dateChooser.getDateEditor().getUiComponent()).getText();
        String gender = null;
        if(male.isSelected()){
            gender = "Male";
        }
        else if(female.isSelected()){
            gender = "Female";
        }
        String email = emailnametxt.getText();
        String marital = null;
        if(married.isSelected()){
            marital = "Married";
        }
        else if(unmarried.isSelected()){
            marital = "UnMarried";
        }
        else if(Other.isSelected()){
            marital = "Other";
        }
        String address = addtxt.getText();
        String city = citytxt.getText();
        String state = statetxt.getText();
        String pin = pintxt.getText();
    //    String emailRegex = "[^A-Za-z0-9+_.-]+@(.+)$";
        
        try{
            if(name.equals("")){
                JOptionPane.showMessageDialog(null, "Name is Required");
            }
            else if(!isValidEmail(email)){
                JOptionPane.showMessageDialog(null,"Please enter a valid email");
            }
            else{
                Conn c = new Conn();
                String query = "insert into signup values('"+formno+"','"+name+"','"+fname+"','"+dob+"','"+gender+"','"+email+"','"+marital+"','"+address+"','"+city+"','"+pin+"','"+state+"')";
                c.s.executeUpdate(query);
                setVisible(false);
                new SignupTwo(formno).setVisible(true);
            }
                
            
        }catch(Exception e){
            System.out.println(e);
            
        }
    }
    
    public static void main(String args[]) {
       new SignUpone();
    }
}
