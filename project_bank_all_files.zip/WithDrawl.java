package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Date;
import java.sql.*;


public class WithDrawl extends JFrame implements ActionListener {
    
    JTextField amount;
    JButton withdrawl,back; 
    String pinnumber;
    
    WithDrawl(String pinnumber){
        this.pinnumber=pinnumber;
        
        setLayout(null);
        ImageIcon l1 = new ImageIcon(ClassLoader.getSystemResource("icon/atm.jpg"));
        Image l2 = l1.getImage().getScaledInstance(900,900,Image.SCALE_DEFAULT);
        ImageIcon l3 = new ImageIcon(l2);
        JLabel image = new JLabel(l3);
        image.setBounds(0,0,900,900);
        add(image);
            
        JLabel text = new JLabel("Enter the amount you want to Withdrawl");
        text.setForeground(Color.white);
        //text.setBackground(Color.);
        text.setFont(new Font("System",Font.BOLD,14));
        text.setBounds(170,300,400,20);
        image.add(text);
        
        amount = new JTextField();
        amount.setFont(new Font("Raleway",Font.BOLD,22));
        amount.setBounds(170,350,320,25);
        image.add(amount);
        
        withdrawl = new JButton("WithDraw");
        withdrawl.setBounds(355,485,150,30);
        withdrawl.addActionListener(this);
        image.add(withdrawl);
        
        back = new JButton("Back");
        back.setBounds(355,520,150,30);
        back.addActionListener(this);
        image.add(back);
        
        setSize(900,900);
        setLocation(300,0);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==withdrawl){
            processWithdrawal();
        } else if(ae.getSource()==back){
            setVisible(false);
            new Transcation(pinnumber).setVisible(true);
        }
    }
        private void processWithdrawal() {
    String number = amount.getText();
    Date date = new Date();
    
    if (number.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please enter the amount you want to withdraw");
        return;
    }
    
    try {
        int withdrawalAmount = Integer.parseInt(number);
        if (withdrawalAmount <= 0) {
            JOptionPane.showMessageDialog(null, "Withdrawal amount must be positive");
            return;
        }
        
        // Check current balance
        int currentBalance = getCurrentBalance();
        if (withdrawalAmount > currentBalance) {
            JOptionPane.showMessageDialog(null, 
                "Insufficient funds\nAvailable balance: Rs " + currentBalance);
            return;
        }
        
        // Process withdrawal
        try (Conn conn = new Conn()) {
            String query = "INSERT INTO bank VALUES(?, ?, ?, ?)";
            PreparedStatement pstmt = conn.c.prepareStatement(query);
            pstmt.setString(1, pinnumber);
            pstmt.setString(2, date.toString());
            pstmt.setString(3, "Withdrawal");
            pstmt.setString(4, number);
            pstmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Rs " + number + " Withdrawn Successfully");
            setVisible(false);
            new Transcation(pinnumber).setVisible(true);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
            e.printStackTrace();
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Please enter a valid number");
    }
}
    
    private int getCurrentBalance() {
    try (Conn conn = new Conn()) {
        String query = "SELECT SUM(CASE WHEN type = 'Deposit' THEN amount ELSE -amount END) " +
                      "FROM bank WHERE pin = ?";
        PreparedStatement pstmt = conn.c.prepareStatement(query);
        pstmt.setString(1, pinnumber);
        ResultSet rs = pstmt.executeQuery();
        
        return rs.next() ? rs.getInt(1) : 0;
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error checking balance: " + e.getMessage());
        e.printStackTrace();
        return 0; // or throw a runtime exception if appropriate
    }
}
    public static void main(String args[]) {
        new WithDrawl("");
    }
}
