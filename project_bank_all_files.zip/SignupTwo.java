package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.util.*;

import java.awt.event.*;
//to use calendar field for dob u have to import
//this jar folder
//import com.toedter.calendar.JDateChooser;
public class SignupTwo extends JFrame implements ActionListener {
   // long random;
    JTextField pan,aadhar;
    JRadioButton syes,sno,eyes,eno;
    JButton next;
   // JDateChooser dateChooser;
    JComboBox religion,income,category,grad,occupation;
    String formno;
    
    SignupTwo(String formno){
        //layout should be kept null to use
        //apply setBounds
        this.formno=formno;
        setLayout(null);
        
        setTitle("NEE ACCOUNT APPLICATION FORM-PAGE 2");
        
        JLabel additionDetails = new JLabel("Page 2 : Additional Deatails");
        additionDetails.setFont(new Font("Raleway",Font.BOLD,28));
        additionDetails.setBounds(250,100,600,40);
        add(additionDetails);
        
        JLabel name = new JLabel("Religion:");
        name.setFont(new Font("Raleway",Font.BOLD,20));
        name.setBounds(100,180,600,40);
        add(name);
        //we can use dropdown
         // with help of combobox
         String[] valReligion= {"Hindu","Christian",
         "Muslim","Sikh","Other"};
         religion = new JComboBox(valReligion);
         religion.setBackground(Color.white);
         religion.setBounds(300,190,400,30);
         add(religion);
        
        JLabel fname = new JLabel("Category:");
        fname.setFont(new Font("Raleway",Font.BOLD,20));
        fname.setBounds(100,230,600,40);
        add(fname);
        
        String valCategory[] = {"General","ST","SC","OBC"};
        category = new JComboBox(valCategory);
        category.setBackground(Color.white);
        category.setBounds(300,240,400,30);
        add(category);
        
     
        
        
        JLabel dob = new JLabel("Income:");
        dob.setFont(new Font("Raleway",Font.BOLD,20));
        dob.setBounds(100,280,600,40);
        add(dob);
        
        String valIncome[] = {"< 1Lakh","1 to 2Lakhs","2 to 3Lakhs",">4Lakhs"};
        income = new JComboBox(valIncome);
        income.setBackground(Color.white);
        income.setBounds(300,290,400,30);
        add(income);
        
        
        JLabel gender = new JLabel("Education");
        gender.setFont(new Font("Raleway",Font.BOLD,20));
        gender.setBounds(100,330,600,40);
        add(gender);
        JLabel email = new JLabel("Qualification:");
        email.setFont(new Font("Raleway",Font.BOLD,20));
        email.setBounds(100,350,600,40);
        add(email);
        
        String valgrad[] = {"Not-Graduate","Graduate",
            "Doctrate","Post-Graduation","Other"};
        grad = new JComboBox(valgrad);
        grad.setBackground(Color.white);
        grad.setBounds(300,340,400,30);
        add(grad);
        
  
        
        JLabel maritalsts= new JLabel("Occupation:");
        maritalsts.setFont(new Font("Raleway",Font.BOLD,20));
        maritalsts.setBounds(100,430,600,40);
        add(maritalsts);
        
        String valOccupation[] = {"Salaried","Self-Employed",
            "Student","Retired","Bussiness","Other"};
        occupation = new JComboBox(valOccupation);
        occupation.setBackground(Color.white);
        occupation.setBounds(300,440,400,30);
        add(occupation);
        
        
        JLabel Address= new JLabel("PAN Number:");
        Address.setFont(new Font("Raleway",Font.BOLD,20));
        Address.setBounds(100,480,600,40);
        add(Address);
        
        pan = new JTextField();
        pan.setBounds(300,490,400,30);
        pan.setFont(new Font("Arial",Font.BOLD,14));
        add(pan);
        
        
        JLabel city= new JLabel("Aadhar Number:");
        city.setFont(new Font("Raleway",Font.BOLD,20));
        city.setBounds(100,530,600,40);
        add(city);
        
        aadhar = new JTextField();
        aadhar.setBounds(300,540,400,30);
        aadhar.setFont(new Font("Arial",Font.BOLD,14));
        add(aadhar);
                
        
        JLabel State= new JLabel("Senior Citizen:");
        State.setFont(new Font("Raleway",Font.BOLD,20));
        State.setBounds(100,590,600,40);
        add(State);
        
        syes = new JRadioButton("Yes");
        syes.setBackground(Color.white);
        syes.setBounds(300,594,100,30);
        add(syes);
        
        sno = new JRadioButton("No");
        sno.setBackground(Color.white);
        sno.setBounds(400,594,100,30);
        add(sno);
        
        ButtonGroup citizengroup = new ButtonGroup();
        citizengroup.add(syes);
        citizengroup.add(sno);

        
        JLabel pincode = new JLabel("Exisiting Account:");
        pincode.setFont(new Font("Raleway",Font.BOLD,20));
        pincode.setBounds(100,640,600,40);
        add(pincode);
        
        eyes = new JRadioButton("Yes");
        eyes.setBackground(Color.white);
        eyes.setBounds(300,645,100,30);
        add(eyes);
        
        eno = new JRadioButton("No");
        eno.setBackground(Color.white);
        eno.setBounds(400,645,100,30);
        add(eno);
        
        ButtonGroup ecitizengroup = new ButtonGroup();
        ecitizengroup.add(eyes);
        ecitizengroup.add(eno);
        
//        pintxt = new JTextField();
//        pintxt.setBounds(300,640,400,30);
//        pintxt.setFont(new Font("Arial",Font.BOLD,14));
//        add(pintxt);
        
        next = new JButton("Next");
        next.setFont(new Font("Raleway",Font.BOLD,14));
        next.setBounds(620,700,80,30);
        next.addActionListener(this);
        add(next);
        
        
        getContentPane().setBackground(Color.white);
        setSize(850,800);
        setLocation(350,10);
        setVisible(true);
    }
    
    private boolean isValidPAN(String pan) {
        // PAN format: 5 uppercase letters, 4 digits, 1 uppercase letter
        String panRegex = "[A-Z]{5}[0-9]{4}[A-Z]{1}";
        return pan.matches(panRegex);
    }

    private boolean isValidAadhar(String aadhar) {
        // Aadhar format: 12 digits
        String aadharRegex = "[0-9]{12}";
        return aadhar.matches(aadharRegex);
    }    
    public void actionPerformed(ActionEvent ae){
       // String formno = " " + random;
        String sreligion =  (String) religion.getSelectedItem();
        String scategory = (String) category.getSelectedItem();
        String sincome = (String) income.getSelectedItem();
        String sgrad = (String) grad.getSelectedItem();
        String soccupation = (String) occupation.getSelectedItem();
        String seniorcitizen = null;
        if(syes.isSelected()){
             seniorcitizen = "Yes";
        }
        else if(sno.isSelected()){
            seniorcitizen = "No";
        }
        //String email = emailnametxt.getText();
        String existingaccount = null;
        if(eyes.isSelected()){
            existingaccount = "eyes";
        }
        else if(eno.isSelected()){
            existingaccount = "No";
        }
//        else if(Other.isSelected()){
//            marital = "Other";
//        }
        String span = pan.getText().trim().toUpperCase();
        String saadhar = aadhar.getText().trim();
        //String state = statetxt.getText();
        //String pin = pintxt.getText();
        
        try{  
            if(!isValidPAN(span)){
                JOptionPane.showMessageDialog(null,"Invalid pan number");
                return;
            }
            if(!isValidAadhar(saadhar)){
                JOptionPane.showMessageDialog(null,"Invalid Aadhar Number");
                return;
            }
            Conn c = new Conn();
            String query = "insert into signuptwo values('"+formno+"','"+sreligion+"','"+scategory+"','"+sincome+"','"+sgrad+"','"+soccupation+"','"+span+"','"+saadhar+"','"+existingaccount+"','"+seniorcitizen+"')";
            c.s.executeUpdate(query);
            setVisible(false);
            new SignupThree(formno).setVisible(true);
           }
        catch(Exception e){
            System.out.println(e);
            
        }
    }
    
    public static void main(String args[]) {
        new SignupTwo("");
    }
}
